
package song;

/**
 *
 * @author jyson
 */
public class InheritanceProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FashionBrand company = new FashionBrand("Chanel", "Coco Chanel", 1910);
        Bag bag = new Bag(6400, "Chanel", "Coco Chanel", 1910);
        System.out.println(company);
        System.out.println(bag);
        System.out.println(company.equals(bag));
        System.out.println(bag.equals(company));
    }
    
    
}
