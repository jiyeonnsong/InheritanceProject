package song;

import java.util.Objects;

/**
 *
 * @author jyson
 */
public class Bag extends FashionBrand { // child class is extending parent class

    private double price;

    public Bag(double price, String name, String designer, int year) { // bit different
        super(name, designer, year);
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return super.toString() + " (bag price =  $" + price + ")";
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + (int) (Double.doubleToLongBits(this.price) ^ (Double.doubleToLongBits(this.price) >>> 32));
        hash += super.hashCode(); // super hashCode
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Bag)) { //getClass() only checks the current class. So, using getClass(),  a Van object can only match the Van class, 
                                        //but using instanceof, a Van object will match the Van class and the Automobile class.
            return false;
        }
        final Bag other = (Bag) obj; // modify what I want to compare equal or not
        if (this.getYear() != other.getYear()) { // call getter from parent class
            return false;
        }
        if (!Objects.equals(this.getName(), other.getName())) {
            return false;
        }
        if (!Objects.equals(this.getDesigner(), other.getDesigner())) {
            return false;
        }
        if (Double.doubleToLongBits(this.price) != Double.doubleToLongBits(other.price)) {
            return false;
        }
        return true;
    }

}
